package com.example.splashmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button login2048 = findViewById(R.id.game2048);
        Button loginLightsOut = findViewById(R.id.LightsOut);
        login2048.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), game2048.class);
                startActivityForResult(intent, 0);
            }
        });
        loginLightsOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), Lightsout.class);
                startActivityForResult(intent, 0);
            }
        });
    }
}